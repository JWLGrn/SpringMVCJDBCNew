package tw.com.phctw.controller;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import tw.com.phctw.model.Member;
import tw.com.phctw.service.EmailService;
import tw.com.phctw.service.MemberService;

@Controller
public class MemberController {
	@Autowired
	private MemberService mService;
	
	@Autowired
	private EmailService eService;

	//跳頁
	@RequestMapping(path = "/addMember", method = RequestMethod.GET)
	public String index() {
		return "add";
	}

	//新增
	@RequestMapping(path = "/addMember02", method = RequestMethod.POST)
	public String insertMember02(@RequestParam("account") String account, @RequestParam("password") String passowrd,
			@RequestParam("eMail") String eMail) throws UnsupportedEncodingException, NoSuchAlgorithmException {
		Member member = new Member();
		member.setAccount(account);
		member.setPassword(passowrd);
		member.seteMail(eMail);
		System.out.println(member);
		mService.insertMember02(member);
		System.out.println("你好阿");
		return "addSuccess";

	}
	//找全部會員回傳JSON
	@RequestMapping(path = "/findMember",method = RequestMethod.GET)
	public @ResponseBody List<Member> findMember(){
		List<Member> mList = mService.findAll();
		return mList;
				
		
	}
	
	//找帳號是否重複
	@RequestMapping(path = "/checkAccount",method = RequestMethod.POST)
	public @ResponseBody String checkAccountIsNoRepeat(@RequestParam("account") String account) {
		System.out.println(account+":account");
		boolean checkAccount =mService.selectMemberByAccount(account);
		if(checkAccount) {
			return "0";
		}return "1";
	}

	// 登入
	@RequestMapping(path = "/findMember", method = RequestMethod.POST)
	public String LoginMember(@RequestParam("account") String account, @RequestParam("password") String password,
			Model model) throws NoSuchAlgorithmException, UnsupportedEncodingException {
		Map<String, String> errors = new HashMap<String, String>();
		model.addAttribute("errors", errors);
		errors.put("msg", "請輸入正確帳號或是密碼");
		Member member = new Member();
		member.setAccount(account);
		member.setPassword(password);
		if (account == null || account.length() == 0) {
			errors.put("name", "請輸入帳號");
		}
		if (password == null || password.length() == 0) {
			errors.put("pwd", "請輸入密碼");
		}
		boolean check = mService.findMemberByAccountAndPassword(member);
		if (check) {
			model.addAttribute("account", account);
			model.addAttribute("password", password);
			return "login";
		} else {

			System.out.println(check + ":MemberController結果");
			System.out.println(member);
			errors.put("msg", "請輸入正確帳號或是密碼");
			return "./../../index";
		}

	}
	//忘記密碼
	@RequestMapping(path = "/forgotpassword",method = RequestMethod.POST)
	public String ForgotPassword(@RequestParam("account") String account) throws NoSuchAlgorithmException, UnsupportedEncodingException {
		System.out.println(account+":account");
		Member member = new Member();
		member.setAccount(account);
		String newPassword = mService.updateMemberPassword(member);
		member.setPassword(newPassword);
		String eMail = mService.getEmailByAccount(member);
		member.seteMail(eMail);
		System.out.println(member);
		eService.SendMail(member);
		return "./../../index";
				
	}

}