package tw.com.phctw.model;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository("MemberDao")
public class MemberDao {

	@Autowired
	private JdbcTemplate JdbcTemplate;

	// 找帳號回傳boolean
	public boolean selectMemberByAccount(String account) {
		List<Map<String, Object>> rows = JdbcTemplate
				.queryForList("  select * from member where account ='" + account + "'");
		if (rows.isEmpty()) {
			System.out.println("沒有資料");

			return true;

		} else {
			System.out.println("有資料");

			return false;

		}

	}

	// 找全部回傳JSON
	@SuppressWarnings("unchecked")
	public List<Member> findAll() {

		String sql = "SELECT * FROM member";

		List<Member> member = JdbcTemplate.query(sql, new BeanPropertyRowMapper<Member>(Member.class));

		return member;

	}

	// 新增
	public void insert(Member member) {
		JdbcTemplate.update("INSERT INTO Member (account,password,eMail) " + "VALUES('" + member.getAccount() + "','"
				+ member.getPassword() + "','" + member.geteMail() + "')");
		System.out.println("新增成功");
	}

	// 找帳號和密碼
	public boolean findMemberByAccountAndPassword(Member member) {
		List<Map<String, Object>> rows = JdbcTemplate.queryForList("  select * from member where account ='"
				+ member.getAccount() + "'and password ='" + member.getPassword() + "'");
		if (rows.isEmpty()) {
			System.out.println("沒有資料");
			return false;
		} else {
			System.out.println("有資料");
			return true;
		}
	}

	// 找帳號改密碼
	public int updateMemberPassword(Member member) {

		String SQL = "update member set password = ? where account = ?";
		int row = JdbcTemplate.update(SQL, member.getPassword(), member.getAccount());
		System.out.println("Updated Record with account = " + member.getAccount());
		return row;
	}

	// 用新帳號找信箱
	public String getEmailByAccount(Member member) {
		String sql = "SELECT eMail FROM member WHERE account=?";

		String eMail = (String) JdbcTemplate.queryForObject(sql, String.class, member.getAccount());
		System.out.println(eMail);

		return eMail;
	}

}
