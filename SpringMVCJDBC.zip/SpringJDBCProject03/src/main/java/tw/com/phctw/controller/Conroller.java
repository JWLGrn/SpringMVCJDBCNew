package tw.com.phctw.controller;

import tw.com.phctw.service.EmailService;

public class Conroller {

	public static void main(String[] args) {
		 EmailService e = new EmailService();
//		 e.SendMail();
	}

}
