package tw.com.phctw.service;

import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tw.com.phctw.model.Member;
import tw.com.phctw.model.MemberDao;

@Service
public class MemberService {
	
	@Autowired
	private MemberDao mDao;
	
	//用Ajax找帳號是否重複回傳boolean
	public boolean selectMemberByAccount(String  account) {
		boolean checkAccount=mDao.selectMemberByAccount(account);
		return checkAccount;
		
	}
	
	//新增會員並經過md5加密
	public void insertMember02(Member member) throws  UnsupportedEncodingException, NoSuchAlgorithmException {
        byte[] digest = null;
		MessageDigest md5 = MessageDigest.getInstance("MD5");
		digest = md5.digest(member.getPassword().getBytes("UTF-8"));	
        String md5Str = new BigInteger(1, digest).toString(16);
        member.setPassword(md5Str);
		 mDao.insert(member);
	}
	//ajax回傳會員資料JSON格式
	public List<Member> findAll(){
		return mDao.findAll();
	}
	//找帳照密碼回傳boolean
	public boolean findMemberByAccountAndPassword(Member member) throws NoSuchAlgorithmException, UnsupportedEncodingException {
		 byte[] digest = null;
			MessageDigest md5 = MessageDigest.getInstance("MD5");
			digest = md5.digest(member.getPassword().getBytes("UTF-8"));	
	        String md5Str = new BigInteger(1, digest).toString(16);
	        member.setPassword(md5Str);
		return mDao.findMemberByAccountAndPassword(member);
	}
	//抓取帳號給予新密碼並加密，但回傳不加密的密碼
	 public String updateMemberPassword(Member member) throws NoSuchAlgorithmException, UnsupportedEncodingException {
			char[] passwordChar = new char[5];
			// 隨機給予五位數英文密碼
			for (int j = 1; j < 5; j++) {
				passwordChar[0] = (char) (Math.random() * 26 + 65);
				passwordChar[j] = (char) (Math.random() * 26 + 97);
			}
			//加密MD5
			String stringPassword = new String(passwordChar);
			 byte[] digest = null;
				MessageDigest md5 = MessageDigest.getInstance("MD5");
				digest = md5.digest(stringPassword.getBytes("UTF-8"));	
		        String md5Str = new BigInteger(1, digest).toString(16);
			member.setPassword(md5Str);
			  mDao.updateMemberPassword(member);
			  return stringPassword;
			
	 }
	 //用帳號找密碼
	 public String getEmailByAccount(Member member) {
		 return mDao.getEmailByAccount(member);
	 }
	
	
	
	
	

}
