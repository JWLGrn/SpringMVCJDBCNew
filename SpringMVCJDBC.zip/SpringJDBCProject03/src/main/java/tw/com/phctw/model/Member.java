package tw.com.phctw.model;

public class Member {
	
	
	private String account;
	
	private String password;
	
	private String eMail;
	
	

	public Member() {
		super();
	}



	public Member(String account, String password, String eMail) {
		super();
		this.account = account;
		this.password = password;
		this.eMail = eMail;
	}



	public String getAccount() {
		return account;
	}



	public void setAccount(String account) {
		this.account = account;
	}



	public String getPassword() {
		return password;
	}



	public void setPassword(String password) {
		this.password = password;
	}



	public String geteMail() {
		return eMail;
	}



	public void seteMail(String eMail) {
		this.eMail = eMail;
	}



	@Override
	public String toString() {
		return "Memeber [account=" + account + ", password=" + password + ", eMail=" + eMail + "]";
	}
	
	
	

}
